1.Open the project folder in the any text editor (VS Code).
2.Open the terminal in the editor and run "npm install".
3.Then run "npm servers".
4.Open the html file and enter the data in the input field. 