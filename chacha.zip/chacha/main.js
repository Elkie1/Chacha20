const encryptBtn = document.querySelector('.btn-cipher');
const input = document.querySelector('input[type="text"]');
const encryptedText = document.querySelector('.encrypted-text');
const decryptedText = document.querySelector('.decrypted-text');
const executionText = document.querySelector('.execution-text')
const truputText = document.querySelector('.throughput-text')
const decutionText = document.querySelector('.decution-text');
const decThruputText = document.querySelector('.dec-throughput-text');
const encMemText = document.querySelector('.enc-memory-text');
const decMemText = document.querySelector('.dec-memory-text');


encryptBtn.addEventListener('click', (e)=>{
    e.preventDefault()
    const inputVal = input.value;

    if(inputVal.length){
        console.log(inputVal);
        fetch("http://localhost:3000/home", {
        method: 'post',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            value: inputVal
        })
    })
    .then(res=> res.json())
    .then(data=> {
        encryptedText.textContent = data.data1;
        executionText.textContent = data.data2 + ' ms';
        truputText.textContent = data.data3 + ' kb/ms';
        encMemText.textContent = data.data4 + ' MB';
        
        decryptedText.textContent = data.data5;
        decutionText.textContent = data.data6 + ' ms';
        decThruputText.textContent = data.data7 + ' kb/ms';
        decMemText.textContent = data.data8 + ' MB';
    })
    }

    
})