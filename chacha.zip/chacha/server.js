var chacha20 = require("chacha20");

var key = new Buffer(32);
key.fill(0);
var nonce = new Buffer(8);
nonce.fill(0);

var plaintext = "testing";
// pass in buffers, returns a buffer
var ciphertext = chacha20.encrypt(key, nonce, new Buffer(plaintext));
console.log(ciphertext.toString("hex")); // prints "02dd93d9c99f5a"
console.log(chacha20.decrypt(key, nonce, ciphertext).toString()); // prints "testing"