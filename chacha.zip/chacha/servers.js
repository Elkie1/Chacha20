const express = require('express');
const process = require('process')
const app = express();
const cors = require('cors');
const bodyParser = require('body-parser');
const chacha20 = require('chacha20');
const PORT = 3000;

app.use(cors())
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())

app.post('/home', (req, res)=>{

    const plaintext = req.body.value;
    
    //Compute encryption
    var textSize = Buffer.byteLength(plaintext, 'utf8')
    var convertedSize = textSize / 1024;
    var key = new Buffer(32);
    key.fill(0);
    var nonce = new Buffer(32);
    nonce.fill(0);

    var tm0 = performance.now()
    var ciphertext = chacha20.encrypt(key, nonce, new Buffer(plaintext))
    const memEnc = process.memoryUsage().heapUsed / 1024 / 1024;
    var tm1 = performance.now()

    var executionTm = tm1 - tm0;
    var encThruput = convertedSize / executionTm;

    //Compute decryption
    var decTextSize = Buffer.byteLength(ciphertext, 'utf8')
    var convertedDecSize = decTextSize / 1024;

    var deTm0 = performance.now()
    var decipher = chacha20.decrypt(key, nonce, ciphertext).toString()
    const memDec = process.memoryUsage().heapUsed / 1024 / 1024;
    var deTm1 = performance.now()

    var dec = deTm1 - deTm0;
    var decThruput = convertedDecSize / dec;

    res.send({data1: ciphertext.toString("hex"), data2: executionTm, data3: encThruput, data4: memEnc, data5: decipher, data6: dec, data7: decThruput, data8: memDec})

})

app.listen(PORT, ()=>{
    console.log('Live and running');
})
